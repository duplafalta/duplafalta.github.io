## jQuery Picasa Gallery v1.0
jQuery plugin that displays your public picasa web albums on your website in a photo gallery.

### Example
<http://alanhamlett.github.com/jQuery-Picasa-Gallery>

### Download
<https://github.com/alanhamlett/jQuery-Picasa-Gallery/tarball/master>

### Project Page
<http://alanhamlett.github.com/jQuery-Picasa-Gallery>

### License
Released under the [MIT license](http://www.opensource.org/licenses/mit-license.php).
Uses the [fancyBox](http://fancyapps.com/fancybox/) jQuery plugin, which is free for non-commercial use.

